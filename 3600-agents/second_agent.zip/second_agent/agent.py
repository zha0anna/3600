from collections.abc import Callable
from typing import List, Tuple, Optional
import random

from game import board, move, enums
from game.enums import MoveType, Direction, CARPET_POINTS_TABLE, Cell, BOARD_SIZE


class PlayerAgent:
    """
    Smart agent using iterative deepening alpha-beta minimax with a
    hand-crafted evaluation function.
    """

    def __init__(self, board, transition_matrix=None, time_left: Callable = None):
        self.turn = 0
        self.best_move_this_iteration = None  # stores best move found so far during iterative deepening

    def commentate(self):
        return f"Finished {self.turn} turns. Final score: {self._last_points if hasattr(self, '_last_points') else '?'}"

    def play(self, board, sensor_data: Tuple, time_left: Callable):
        self.turn += 1
        self._last_points = board.player_worker.get_points()

        moves = board.get_valid_moves()
        if not moves:
            return None

        # Order moves best-first so alpha-beta prunes more aggressively
        moves = self._order_moves(moves)

        best_move = moves[0]  # fallback: best move by ordering heuristic

        # Iterative deepening: search depth 1, 2, 3... until time runs low
        for depth in range(1, 6):
            if time_left() < 8:  # stop searching if under 8 seconds total remaining
                break

            self.best_move_this_iteration = None
            self._alphabeta_root(board, depth, moves, time_left)

            # Only update best_move if we completed this depth's search
            if self.best_move_this_iteration is not None:
                best_move = self.best_move_this_iteration

        return best_move

    # -----------------------------------------------------------------------
    # ALPHA-BETA SEARCH
    # -----------------------------------------------------------------------

    def _alphabeta_root(self, board, depth, moves, time_left):
        alpha = float('-inf')
        beta = float('inf')
        best_score = float('-inf')

        for m in moves:
            if time_left() < 8:
                return

            new_board = board.forecast_move(m, check_ok=False)
            if new_board is None:
                continue

        # Do NOT reverse_perspective — just pass is_my_turn=False
            score = self._alphabeta(new_board, depth - 1, alpha, beta, is_my_turn=False, time_left=time_left)

            if score > best_score:
                best_score = score
                self.best_move_this_iteration = m

            alpha = max(alpha, best_score)

    def _alphabeta(self, board, depth, alpha, beta, is_my_turn, time_left):
        if depth == 0 or board.is_game_over() or time_left() < 8:
            return self._evaluate(board)  # always evaluate from original player's perspective

    # Get moves for whoever's turn it actually is
        moves = board.get_valid_moves(enemy=not is_my_turn)
        if not moves:
            return self._evaluate(board)

        moves = self._order_moves(moves)

        if is_my_turn:
            value = float('-inf')
            for m in moves:
                new_board = board.forecast_move(m, check_ok=False)
                if new_board is None:
                    continue
            # No reverse_perspective
                score = self._alphabeta(new_board, depth - 1, alpha, beta, is_my_turn=False, time_left=time_left)
                value = max(value, score)
                alpha = max(alpha, value)
                if alpha >= beta:
                    break
            return value

        else:
            value = float('inf')
            for m in moves:
                new_board = board.forecast_move(m, check_ok=False)
                if new_board is None:
                    continue
                score = self._alphabeta(new_board, depth - 1, alpha, beta, is_my_turn=True, time_left=time_left)
                value = min(value, score)
                beta = min(beta, value)
                if alpha >= beta:
                    break
            return value

    # -----------------------------------------------------------------------
    # EVALUATION FUNCTION
    # -----------------------------------------------------------------------

    def _evaluate(self, board) -> float:
    # player_worker is always OUR worker since we never reverse_perspective
        my_points = board.player_worker.get_points()
        opp_points = board.opponent_worker.get_points()
        score = (my_points - opp_points) * 10.0

        my_run_value = self._score_primed_runs(board, board.player_worker.get_location())
        opp_run_value = self._score_primed_runs(board, board.opponent_worker.get_location())
        score += my_run_value * 2.0
        score -= opp_run_value * 1.0

        my_moves = len(board.get_valid_moves(enemy=False))
        opp_moves = len(board.get_valid_moves(enemy=True))
        score += (my_moves - opp_moves) * 0.3

        return score

    def _score_primed_runs(self, board, worker_loc: Tuple) -> float:
        """
        Find contiguous horizontal and vertical runs of primed squares
        and sum their potential carpet scores. Weighted by proximity to worker.
        """
        total = 0.0
        wx, wy = worker_loc

        # Check horizontal runs
        for y in range(BOARD_SIZE):
            run_length = 0
            run_start_x = 0
            for x in range(BOARD_SIZE):
                cell = board.get_cell((x, y))
                if cell == Cell.PRIMED:
                    if run_length == 0:
                        run_start_x = x
                    run_length += 1
                else:
                    if run_length >= 2:
                        points = CARPET_POINTS_TABLE.get(run_length, 21)
                        # Proximity bonus: closer runs are worth more
                        dist = abs(wy - y) + min(abs(wx - run_start_x), abs(wx - (run_start_x + run_length - 1)))
                        proximity = max(1.0, 8.0 - dist)
                        total += points * proximity
                    run_length = 0
            # Handle run ending at board edge
            if run_length >= 2:
                points = CARPET_POINTS_TABLE.get(run_length, 21)
                dist = abs(wy - y) + min(abs(wx - run_start_x), abs(wx - (run_start_x + run_length - 1)))
                proximity = max(1.0, 8.0 - dist)
                total += points * proximity

        # Check vertical runs
        for x in range(BOARD_SIZE):
            run_length = 0
            run_start_y = 0
            for y in range(BOARD_SIZE):
                cell = board.get_cell((x, y))
                if cell == Cell.PRIMED:
                    if run_length == 0:
                        run_start_y = y
                    run_length += 1
                else:
                    if run_length >= 2:
                        points = CARPET_POINTS_TABLE.get(run_length, 21)
                        dist = abs(wx - x) + min(abs(wy - run_start_y), abs(wy - (run_start_y + run_length - 1)))
                        proximity = max(1.0, 8.0 - dist)
                        total += points * proximity
                    run_length = 0
            if run_length >= 2:
                points = CARPET_POINTS_TABLE.get(run_length, 21)
                dist = abs(wx - x) + min(abs(wy - run_start_y), abs(wy - (run_start_y + run_length - 1)))
                proximity = max(1.0, 8.0 - dist)
                total += points * proximity

        return total

    # -----------------------------------------------------------------------
    # MOVE ORDERING
    # -----------------------------------------------------------------------

    def _order_moves(self, moves: List) -> List:
        """
        Sort moves best-first so alpha-beta prunes as many branches as possible.

        Priority order:
          1. High-value carpet rolls (longest = most points)
          2. Prime moves (setup for future carpets)
          3. Plain moves (neutral repositioning)
          4. Search moves (rat — last resort here, your partner handles these)
        """
        def move_score(m):
            if m.move_type == MoveType.CARPET:
                # Positive carpet scores first; avoid roll=1 which scores -1
                return 100 + CARPET_POINTS_TABLE.get(m.roll_length, -99)
            elif m.move_type == MoveType.PRIME:
                return 10
            elif m.move_type == MoveType.PLAIN:
                return 1
            else:  # SEARCH
                return 0

        return sorted(moves, key=move_score, reverse=True)

    # -----------------------------------------------------------------------
    # HELPERS
    # -----------------------------------------------------------------------

    def _open_squares_in_direction(self, pos: Tuple, direction: Direction, board) -> int:
        """
        Count primed and open squares in a direction beyond a given position.
        Used to score prime moves — more open space ahead = better setup.
        """
        dir_dict = {
            Direction.UP:    (0, -1),
            Direction.DOWN:  (0,  1),
            Direction.LEFT:  (-1, 0),
            Direction.RIGHT: ( 1, 0),
        }
        dx, dy = dir_dict[direction]
        x, y = pos

        count = 0
        # Skip 2: one for the square we're on, one for the square we're priming
        cx, cy = x + dx * 2, y + dy * 2

        for _ in range(6):  # max carpet roll is 7, minus the primed square
            if not (0 <= cx < BOARD_SIZE and 0 <= cy < BOARD_SIZE):
                break
            cell = board.get_cell((cx, cy))
            if cell == Cell.PRIMED:
                count += 2  # already primed = immediately carpetable
            elif cell == Cell.SPACE:
                count += 1  # open = future priming potential
            else:
                break       # blocked or already carpeted — run ends here
            cx += dx
            cy += dy

        return count